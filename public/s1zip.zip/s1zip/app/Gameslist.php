<?php

namespace App;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Jenssegers\Mongodb\Eloquent\Model;
use Carbon\Carbon;

class Gameslist extends Model {

    protected $connection = 'mongodb';
    protected $collection = 'gameslist';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id', 'name', 'desc', 'provider', 'd', 'category', 'image'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'data' => 'json'
    ];


    public static function cachedList() {
        $cachedList = Cache::get('cachedList');  

        if (!$cachedList) { 
            $cachedList = \App\Gameslist::where('d', '!=', '1')->get();
            Cache::put('cachedList', $cachedList, Carbon::now()->addMinutes(120));
        } 

        return $cachedList;
    }
}
