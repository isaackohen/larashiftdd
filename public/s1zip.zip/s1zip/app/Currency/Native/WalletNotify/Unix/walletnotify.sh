#!/bin/bash
curl http://localhost/api/walletNotify/$1/$2
