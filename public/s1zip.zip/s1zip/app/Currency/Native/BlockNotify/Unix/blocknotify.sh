#!/bin/bash
curl http://localhost/api/blockNotify/$1/$2
