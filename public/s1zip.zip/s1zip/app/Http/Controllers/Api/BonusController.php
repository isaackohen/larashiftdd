<?php

namespace App\Http\Controllers\Api;

use \Cache;
use App\Promocode;
use Carbon\Carbon;
use App\Transaction;
use App\Utils\APIResponse;
use App\Currency\Currency;
use Illuminate\Http\Request;

class BonusController
{
	
	public function activatePromo(Request $request) 
	{
        $promocode = Promocode::where('code', $request->code)->first();
        if($promocode == null) return APIResponse::reject(1, 'Invalid promocode');
        if($promocode->expires->timestamp != Carbon::minValue()->timestamp && $promocode->expires->isPast()) return APIResponse::reject(2, 'Expired (time)');
        if($promocode->usages != -1 && $promocode->times_used >= $promocode->usages) return APIResponse::reject(3, 'Expired (usages)');
        if(($promocode->vip ?? false) && auth('sanctum')->user()->vipLevel() == 0) return APIResponse::reject(7, 'VIP only');
        if(in_array(auth('sanctum')->user()->_id, $promocode->used)) return APIResponse::reject(4, 'Already activated');
        if(auth('sanctum')->user()->balance(auth('sanctum')->user()->clientCurrency())->get() > floatval(auth('sanctum')->user()->clientCurrency()->option('withdraw')) / 2) return APIResponse::reject(8, 'Invalid balance');

        if(auth('sanctum')->user()->vipLevel() < 3 || ($promocode->vip ?? false) == false) {
            if (auth('sanctum')->user()->promocode_limit_reset == null || auth('sanctum')->user()->promocode_limit_reset->isPast()) {
                auth('sanctum')->user()->update([
                    'promocode_limit_reset' => Carbon::now()->addHours(auth('sanctum')->user()->vipLevel() >= 5 ? 6 : 12)->format('Y-m-d H:i:s'),
                    'promocode_limit' => 0
                ]);
            }

            if (auth('sanctum')->user()->promocode_limit != null && auth('sanctum')->user()->promocode_limit >= (auth('sanctum')->user()->vipLevel() >= 2 ? 8 : 5)) return APIResponse::reject(5, 'Promocode timeout');
        }

        if(auth('sanctum')->user()->vipLevel() < 3 || ($promocode->vip ?? false) == false) {
            auth('sanctum')->user()->update([
                'promocode_limit' => auth('sanctum')->user()->promocode_limit == null ? 1 : auth('sanctum')->user()->promocode_limit + 1
            ]);
        }

        $used = $promocode->used;
        array_push($used, auth('sanctum')->user()->_id);

        $promocode->update([
            'times_used' => $promocode->times_used + 1,
            'used' => $used
        ]);

        auth('sanctum')->user()->balance(Currency::find($promocode->currency))->add($promocode->sum, Transaction::builder()->message('Promocode')->get());
        return APIResponse::success();
	}
	
	public function demo(Request $request) 
	{
        if(auth('sanctum')->user()->balance(auth('sanctum')->user()->clientCurrency())->demo()->get() > auth('sanctum')->user()->clientCurrency()->minBet()) return APIResponse::reject(1, 'Demo balance is higher than zero');
        auth('sanctum')->user()->balance(auth('sanctum')->user()->clientCurrency())->demo()->add(auth('sanctum')->user()->clientCurrency()->option('demo'), Transaction::builder()->message('Demo')->get());
        return APIResponse::success();
	}
	
	public function partnerBonus(Request $request) 
	{
        if(count(auth('sanctum')->user()->referral_wager_obtainer ?? []) < 10 || count(auth('sanctum')->user()->referral_wager_obtained ?? []) < ((auth('sanctum')->user()->referral_bonus_obtained ?? 0) + 1) * 10) return APIResponse::reject(1, 'Not enough referrals');

        $v = floatval(auth('sanctum')->user()->clientCurrency()->option('referral_bonus_wheel'));
        $slices = [
            $v,
            $v * 1.15,
            $v * 1.3,
            $v * 1.15,
            $v * 1.5,
            $v,
            $v * 2,
            $v,
            $v * 1.15,
            $v * 1.3,
            $v * 1.15,
            $v * 1.5,
            $v,
            $v * 2
        ];

        $slice = mt_rand(0, count($slices) - 1);
        auth('sanctum')->user()->balance(auth('sanctum')->user()->clientCurrency())->add($slices[$slice], \App\Transaction::builder()->message('Referral bonus wheel')->get());
        auth('sanctum')->user()->update([
            'referral_bonus_obtained' => (auth('sanctum')->user()->referral_bonus_obtained ?? 0) + 1
        ]);

        return APIResponse::success([
            'slice' => $slice
        ]);
	}
	
	public function bonus(Request $request) 
	{
        if(auth('sanctum')->user()->bonus_claim != null && !auth('sanctum')->user()->bonus_claim->isPast()) return APIResponse::reject(1, 'Timeout');
        if(auth('sanctum')->user()->balance(auth('sanctum')->user()->clientCurrency())->get() > auth('sanctum')->user()->clientCurrency()->minBet() * 2) return APIResponse::reject(2, 'Balance is greater than zero');

        $currency = auth('sanctum')->user()->clientCurrency();

        $slices = [
            [40, $currency->convertUSDToToken(0.30)],
            [30, $currency->convertUSDToToken(0.40)],
            [21, $currency->convertUSDToToken(0.50)],
            [15, $currency->convertUSDToToken(0.80)],
            [15, $currency->convertUSDToToken(1)],
            [7, $currency->convertUSDToToken(2)],
            [0.80, $currency->convertUSDToToken(3)],
            [0.50, $currency->convertUSDToToken(5)],
            [0.35, $currency->convertUSDToToken(7)],
            [0.20, $currency->convertUSDToToken(10)],
            [0.05, $currency->convertUSDToToken(50)]
        ];

        $slice = 0;

        foreach ($slices as $index => $bonusData) {
            if(mt_rand(1, 101) / 100 < $bonusData[0] / 100) {
                $slice = $index;
                break;
            }
        }

        auth('sanctum')->user()->balance(auth('sanctum')->user()->clientCurrency())->add($slices[$slice][1], Transaction::builder()->message('Faucet')->get());
        auth('sanctum')->user()->update(['bonus_claim' => Carbon::now()->addMinutes(20)]);

        return APIResponse::success([
            'slice' => $slice,
            'next' => Carbon::now()->addMinutes(20)->timestamp
        ]);
	}
	
	public function vipBonus(Request $request) 
	{
        if(auth('sanctum')->user()->vipLevel() == 0) return APIResponse::reject(1, 'Invalid VIP level');
        if(auth('sanctum')->user()->weekly_bonus < 0.1) return APIResponse::reject(2, 'Weekly bonus is too small');
        if(auth('sanctum')->user()->weekly_bonus_obtained) return APIResponse::reject(3, 'Already obtained in this week');
        auth('sanctum')->user()->balance(auth('sanctum')->user()->clientCurrency())->add(((auth('sanctum')->user()->weekly_bonus ?? 0) / 100) * auth('sanctum')->user()->vipBonus(), Transaction::builder()->message('Weekly VIP bonus')->get());
        auth('sanctum')->user()->update([
            'weekly_bonus_obtained' => true
        ]);
        return APIResponse::success();
	}
	
	public function telegram(Request $request) 
	{
		if(auth('sanctum')->user()->telegram == null) return APIResponse::reject(1);
		if(auth('sanctum')->user()->telegram_bonus) return APIResponse::reject(2);
		auth('sanctum')->user()->update([
			'telegram_bonus' => true
		]);
		auth('sanctum')->user()->balance(auth('sanctum')->user()->clientCurrency())->add(floatval(auth('sanctum')->user()->clientCurrency()->option('telegram')), Transaction::builder()->message('Telegram bonus')->get());
		return APIResponse::success();
	}
	
}
