<?php

namespace App\Http\Controllers\Api;

use \Cache;
use App\Utils\APIResponse;
use App\Currency\Currency;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Currency\Aggregator\Aggregator;

class PaymentsController
{
	
	public function walletNotify($currency, $txid) 
	{
		Currency::find($currency)->process($txid);
		return APIResponse::success();
	}
	
	public function blockNotify($currency, $blockId) 
	{
		Currency::find($currency)->processBlock($blockId);
		return APIResponse::success();
	}
	
	public function bitgoWebhook() 
	{
		$sdk = Currency::find('bg_btc')->getSDK();
		$payload = $sdk->getWebhookPayload();

		$currency = Currency::find('bg_'.$payload['coin']);
		if($currency === null) {
			Log::error('Invalid BitGo webhook currency: bg_'.$payload['coin']);
			return APIResponse::reject(1, 'Invalid request');
		}

		$result = $currency->process();
		return APIResponse::success(is_array($result) ? $result : []);
	}
	
	public function paymentStatus(Request $request) 
	{
		$aggregator = null;
		foreach(Aggregator::list() as $ag) {
			if($ag->validate($request)) {
				$aggregator = $ag;
				break;
			}
		}
		if($aggregator == null) return 'Unknown aggregator';
		return $aggregator->status($request);
	}
	
}
