<?php

namespace App\Http\Controllers\Api;

use \Cache;
use App\User;
use Carbon\Carbon;
use App\Settings;
use App\Gameslist;
use App\Leaderboard;
use App\Games\Kernel\Game;
use App\Utils\APIResponse;
use App\Currency\Currency;
use App\Game as GameResult;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Games\Kernel\Module\General\HouseEdgeModule;

class DataController
{
	
	public function latestGames(Request $request) 
	{
		$result = [];
        //return [];

        switch ($request->type) {
            case 'mine':
                $games = GameResult::latest()->where('demo', '!=', true)->where('user', auth('sanctum')->user()->_id)->where('status', '!=', 'in-progress')->where('status', '!=', 'cancelled')->take($request->count)->get()->reverse();
                break;
            case 'all':
                $games = GameResult::latest()->where('demo', '!=', true)->where('user', '!=', null)->where('status', '!=', 'in-progress')->where('status', '!=', 'cancelled')->take($request->count)->get()->reverse();
                break;
            case 'lucky_wins':
                $games = GameResult::latest()->where('multiplier', '>=', 10)->where('demo', '!=', true)->where('user', '!=', null)->where('status', 'win')->take($request->count)->get()->reverse();
                break;
            case 'high_rollers':
                $hrResult = [];
                $games = GameResult::latest()->where('demo', '!=', true)->where('user', '!=', null)->where('status', '!=', 'in-progress')->where('status', '!=', 'cancelled')->take($request->count)->get()->reverse();
                foreach($games as $game) {
                    if($game->wager < floatval(\App\Currency\Currency::find($game->currency)->option('high_roller_requirement'))) continue;
                    array_push($hrResult, $game);
                }
                $games = $hrResult;
                break;
        }

        foreach($games as $game) 
            if($game->type === 'external') {
            $getgamename = (\App\Gameslist::where('id', $game->game)->first());
            $image = 'Image/https://cdn.davidkohen.com/i/cdn'.$getgamename->image.'?q=95&mask=ellipse&auto=compress&sharp=10&w=20&h=20&fit=crop&usm=5&fm=png';
            $meta = array('id' => $game->game, 'icon' => $image, 'name' => $getgamename->name, 'category' => array($getgamename->category));
            array_push($result, [
            'game' => $game->toArray(),
            'user' => User::where('_id', $game->user)->first()->toArray(),
            'metadata' => $meta
            ]);

            } else {
            array_push($result, [
            'game' => $game->toArray(),
            'user' => User::where('_id', $game->user)->first()->toArray(),
            'metadata' => Game::find($game->game)->metadata()->toArray()
            ]);
            }
        return APIResponse::success($result);
	}
	
	public function notifications(Request $request) 
	{
		return APIResponse::success(array_merge(\App\GlobalNotification::get()->toArray(), env('APP_DEBUG') && !str_contains(request()->url(), 'localhost') ? [[
            '_id' => '-1',
            'icon' => 'fad fa-exclamation-triangle',
            'text' => 'Debug'
        ]] : []));
	}


    public static function cachedGames()
    {
        
        $games = [];
        foreach(Game::list() as $game) {
            $houseEdgeModule = new HouseEdgeModule($game, null, null, null);

            array_push($games, [
                'isDisabled' => $game->isDisabled(),
                'isPlaceholder' => $game->metadata()->isPlaceholder(),
                'ext' => false,
                'name' => $game->metadata()->name(),
                'id' => $game->metadata()->id(),
                'icon' => $game->metadata()->icon(),
                'cat' => $game->metadata()->category(),
                'p' => 'inhouse',
                'type' => 'local',
                'houseEdge' => !\App\Modules::get($game, false)->isEnabled($houseEdgeModule) ? null : floatval(\App\Modules::get($game, false)->get($houseEdgeModule, 'house_edge_option'))
            ]);
        }
        
        $thirdpartyGames = Gameslist::cachedList(); 
        foreach($thirdpartyGames as $game) {

            if($game->category === 'live-table' || $game->category === 'live') {
            $gameCategory = 'live';
            } else {
            $gameCategory = $game->category;
            }

            array_push($games, [
                'ext' => true,
                'name' => $game->name,
                'id' => $game->id,
                'icon' => $game->image,
                'cat' => array($gameCategory),
                'p' => $game->provider,
                'type' => 'external'            ]);
        }
        return $games;
    }
	
	public function games(Request $request) 
	{
        $gamesCached = Cache::get('gamesCached');  

        if (!$gamesCached) { 
            $gamesCached = self::cachedGames();
            Cache::put('gamesCached', $gamesCached, Carbon::now()->addMinutes(20));
        } 

        return APIResponse::success($gamesCached);

	}
	
    public static function cachedgamesExternal()
    {
        $games = [];
        $thirdpartyGames = Gameslist::get();
        $popularGames = Settings::get('category_popular');
        $newGames = Settings::get('category_new');
        $gameshowsGames = Settings::get('category_gameshows');
        $bonusGames = Settings::get('category_bonus');
        $featuredGames = Settings::get('category_featured');
        $cardGames = Settings::get('category_cardgames');

        foreach(Game::list() as $game) {
            $houseEdgeModule = new HouseEdgeModule($game, null, null, null);

            array_push($games, [
                'isDisabled' => $game->isDisabled(),
                'isPlaceholder' => $game->metadata()->isPlaceholder(),
                'ext' => false,
                'name' => $game->metadata()->name(),
                'id' => $game->metadata()->id(),
                'icon' => $game->metadata()->icon(),
                'cat' => array('inhouse'),
                'p' => 'provablyfair',
                'type' => 'local',
                'houseEdge' => !\App\Modules::get($game, false)->isEnabled($houseEdgeModule) ? null : floatval(\App\Modules::get($game, false)->get($houseEdgeModule, 'house_edge_option'))
            ]);
        }

          foreach($thirdpartyGames as $game) {
             if($game->category === 'scratch-cards') {
                array_push($games, [
                    'ext' => true,
                    'name' => $game->name,
                    'id' => $game->id,
                    'icon' => $game->image,
                    'cat' => array('scratchcards'),
                    'p' => $game->provider,
                    'type' => 'external'
                ]);
            }
             if($game->category === 'virtualsports') {
                array_push($games, [
                    'ext' => true,
                    'name' => $game->name,
                    'id' => $game->id,
                    'icon' => $game->image,
                    'cat' => array('vs'),
                    'p' => $game->provider,
                    'type' => 'external'
                ]);
            }

            if(in_array($game["id"], explode(',', $featuredGames))) {
                array_push($games, [
                    'ext' => true,
                    'name' => $game->name,
                    'id' => $game->id,
                    'icon' => $game->image,
                    'cat' => array('featured'),
                    'p' => $game->provider,
                    'type' => 'external'
                ]);
            }

            if(in_array($game["id"], explode(',', $bonusGames))) {
                array_push($games, [
                    'ext' => true,
                    'name' => $game->name,
                    'id' => $game->id,
                    'icon' => $game->image,
                    'cat' => array('bonus'),
                    'p' => $game->provider,
                    'type' => 'external'
                ]);
            }

            if(in_array($game["id"], explode(',', $gameshowsGames))) {
                array_push($games, [
                    'ext' => true,
                    'name' => $game->name,
                    'id' => $game->id,
                    'icon' => $game->image,
                    'cat' => array('gameshow'),
                    'p' => $game->provider,
                    'type' => 'external'
                ]);
            }
            if(in_array($game["id"], explode(',', $cardGames))) {
                array_push($games, [
                    'ext' => true,
                    'name' => $game->name,
                    'id' => $game->id,
                    'icon' => $game->image,
                    'cat' => array('card'),
                    'p' => $game->provider,
                    'type' => 'external'
                ]);
            }

            if(in_array($game["id"], explode(',', $popularGames))) {
                array_push($games, [
                    'ext' => true,
                    'name' => $game->name,
                    'id' => $game->id,
                    'icon' => $game->image,
                    'cat' => array('popular'),
                    'p' => $game->provider,
                    'type' => 'external'
                ]);
            }

            if(in_array($game["id"], explode(',', $newGames))) {
                array_push($games, [
                    'ext' => true,
                    'name' => $game->name,
                    'id' => $game->id,
                    'icon' => $game->image,
                    'cat' => array('new'),
                    'p' => $game->provider,
                    'type' => 'external'
                ]);
            }
        }
        return $games;

    }


	public function gamesExternal() 
	{
        $cachedgamesExternal = Cache::get('cachedgamesExternal');  

        if (!$cachedgamesExternal) { 
            $cachedgamesExternal = self::cachedgamesExternal();
            Cache::put('cachedgamesExternal', $cachedgamesExternal, Carbon::now()->addMinutes(20));
        } 

        return APIResponse::success($cachedgamesExternal);
	}
	
	public function currencies(Request $request) 
	{
		return APIResponse::success(Currency::toCurrencyArray(Currency::all()));
	}
	
	public function leaderboard(Request $request) 
	{
		$currency = Currency::find($request->currency ?? '');
		if(!$currency) return APIResponse::reject(2, 'Invalid currency');
		return APIResponse::success(Leaderboard::getLeaderboard($request->positions, $request->type, $currency, $request->orderBy));
	}
	
	public function gameFind(Request $request) 
	{
		$currency = Currency::find($request->currency ?? '');
		$game = Game::where('id', intval($request->id))->first();
        if($game == null) return APIResponse::reject(1, 'Unknown ID ' . $request->id);
        return APIResponse::success([
            'id' => $game->_id,
            'game' => $game->game
        ]);
	}
	
}
