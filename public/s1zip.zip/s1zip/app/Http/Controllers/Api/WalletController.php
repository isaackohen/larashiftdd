<?php

namespace App\Http\Controllers\Api;

use \Cache;
use App\Invoice;
use App\Withdraw;
use App\Transaction;
use App\Utils\APIResponse;
use App\Currency\Currency;
use Illuminate\Http\Request;

class WalletController
{
	
	public function deposit(Request $request) 
	{
        $minimal = floatval(Currency::find('local_rub')->option('min_deposit'));
        if(auth()->user()->vipLevel() >= 4) $minimal /= 2;

        if(floatval($request->sum) < $minimal) return APIResponse::reject(1, 'Invalid deposit value');
        $aggregator = Aggregator::find($request->aggregator);
        if($aggregator == null) return APIResponse::reject(2, 'Invalid aggregator');

        $invoice = Invoice::create([
            'method' => $request->type,
            'sum' => floatval($request->sum),
            'user' => auth()->user()->_id,
            'aggregator' => $aggregator->id(),
            'currency' => 'local_rub',
            'status' => 0
        ]);

        return APIResponse::success([
            'url' => $aggregator->invoice($invoice)
        ]);
	}
	
	public function historyDeposits(Request $request) 
	{	
		return APIResponse::success(Invoice::where('user', auth()->user()->_id)->latest()->get()->toArray());
	}
	
	public function historyWithdraws(Request $request) 
	{
		return APIResponse::success(Withdraw::where('user', auth()->user()->_id)->latest()->get()->toArray());
	}
	
	public function getDepositWallet(Request $request) 
	{
		$currency = Currency::find($request->currency);
        $wallet = auth('sanctum')->user()->depositWallet($currency);
        if($currency == null || !$currency->isRunning() || $wallet === 'Error') return APIResponse::reject(1);
        return APIResponse::success([
            'currency' => $request->currency,
            'wallet' => $wallet
        ]);
	}
	
	public function withdraw(Request $request) 
	{
		if(!auth('sanctum')->user()->validate2FA(false)) return APIResponse::invalid2FASession();
        auth('sanctum')->user()->reset2FAOneTimeToken();

        $currency = Currency::find($request->currency);

        if($request->sum < floatval($currency->option('withdraw')) + floatval($currency->option('fee'))) return APIResponse::reject(1, 'Invalid withdraw value');
        if(auth('sanctum')->user()->balance($currency)->get() < $request->sum + floatval($currency->option('fee'))) return APIResponse::reject(2, 'Not enough balance');
        if(Withdraw::where('user', auth('sanctum')->user()->_id)->where('status', 0)->count() > 0) return APIResponse::reject(3, 'Moderation is still in process');

        auth('sanctum')->user()->balance($currency)->subtract($request->sum + floatval($currency->option('fee')), Transaction::builder()->message('Withdraw')->get());

        Withdraw::create([
            'user' => auth('sanctum')->user()->_id,
            'sum' => $request->sum,
            'currency' => $currency->id(),
            'address' => $request->wallet,
            'status' => 0,
            'type' => $request->type
        ]);

        return APIResponse::success([
            'notifyAboutVip' => auth('sanctum')->user()->vipLevel() >= 5
        ]);
	}
	
	public function cancelWithdraw(Request $request) 
	{
        $withdraw = Withdraw::where('_id', $request->id)->where('user', auth('sanctum')->user()->_id)->where('status', 0)->first();
        if($withdraw == null) return APIResponse::reject(1, 'Hacking attempt');
        if($withdraw->auto) return APIResponse::reject(2, 'Auto-withdrawals cannot be cancelled');
        $withdraw->update([
            'status' => 4
        ]);
        auth('sanctum')->user()->balance(Currency::find($withdraw->currency))->add($withdraw->sum, Transaction::builder()->message('Withdraw cancellation')->get());
        return APIResponse::success();
	}
	
}
