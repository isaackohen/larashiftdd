<?php

namespace App\Http\Controllers\Api;

use \Cache;
use App\User;
use App\Game;
use Carbon\Carbon;
use App\Gameslist;
use App\Transaction;
use App\Leaderboard;
use App\Utils\APIResponse;
use App\Currency\Currency;
use Illuminate\Http\Request;
use App\Events\LiveFeedGame;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class ExternalController
{
	
	public function methodBalance(Request $request) 
	{
		$user = User::where('_id', $_GET["playerid"])->first();
        $currency = Currency::find($_GET["currency"]);
        $getBalance = $user->balance($currency)->get();
        $getBalanceUSD = intval($currency->convertTokenToUSD($getBalance) * 100);

        $responsePayload = array('status' => 'ok', 'result' => array('balance' => $getBalanceUSD, 'freegames' => 0));

        echo json_encode($responsePayload);
    }
	
	public function methodBet(Request $request) 
	{
		Log::alert($request->fullUrl());
        $user = User::where('_id', $_GET["playerid"])->first();
        $currency = Currency::find($_GET["currency"]);
        $win = $_GET["win"];
        $bet = $_GET["bet"];
        $final = $_GET["final"];
        $gameid = $_GET["gameid"];
        $roundid = $request["roundid"];

        if($bet > 0) {
            $betFloat = $_GET["bet"] / 100;
            $gameData = json_encode($request);
            $bet = number_format($currency->convertUSDToToken($betFloat), 8, '.', '');
            $user->balance($currency)->subtract(floatval($bet), Transaction::builder()->meta($roundid)->game($gameid)->get());
        }

        if($win > 0) {
            $winFloat = $_GET["win"] / 100;
            $win = number_format($currency->convertUSDToToken($winFloat), 8, '.', '');
            $user->balance($currency)->add(floatval($win), Transaction::builder()->meta($roundid)->game($gameid)->get());
        }


        if($final === '1') {
            $wager = Transaction::where("meta", "=", $roundid)->first()->amount;
            $wagerTrimmed = floatval(trim($wager, '-'));
            Log::critical($wagerTrimmed);
            $win = floatval($win);

            $status = 'lose';
            if($win > $wagerTrimmed) $status = 'win';
            if($wagerTrimmed < 0.0000001) {
                $multi = 0;
            } else {
                $multi = (float) ($win / $wagerTrimmed);
            }
            

            $game = Game::create([
                'id' => DB::table('games')->count() + 1,
                'user' => $user->_id,
                'game' => $gameid,
                'wager' => $wager,
                'multiplier' => $multi,
                'status' => $status,
                'profit' => $win - $wagerTrimmed,
                'server_seed' => '0',
                'client_seed' => '0',
                'nonce' => '0',
                'data' => [],
                'type' => 'external',
                'currency' => $currency->id()
            ]);

            event(new LiveFeedGame($game, '1'));
            Leaderboard::insert($game);
        }
 
        $getBalance = $user->balance($currency)->get();
        $getBalanceUSD = intval($currency->convertTokenToUSD($getBalance) * 100);
        
        $responsePayload = array('status' => 'ok', 'result' => array('balance' => $getBalanceUSD, 'freegames' => 0));

        echo json_encode($responsePayload);
    }
	
	public function methodGetUrl(Request $request) 
	{
		if(auth('sanctum')->guest()) {
			$mode = 'demo';
			$currencyId = 'usd';
		} else {
        $mode = 'real';
        $userId = auth('sanctum')->user()->id;
        $currencyId = auth('sanctum')->user()->clientCurrency()->id();
            }
        //$balanceNative =  auth('sanctum')->user()->balance(auth('sanctum')->user()->clientCurrency())->get();
        $apikey = 'C9A6568E26BA911594C1F52734993CE7';
        $url = "https://api.bulk.bet/v2/createSession?apikey=".$apikey."&userid=".$userId."-".$currencyId."&game=".$request->id."&mode=".$mode;
		Log::notice($url);
        $result = file_get_contents($url);
        $decodeArray = json_decode($result, true);
        $gameslist = (Gameslist::where('id', $request->id)->first());
        return APIResponse::success([
            'url' => $decodeArray['url']
        ]);
    }
	
}
