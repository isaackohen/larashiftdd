<template>
    <div class="gameCategory">
        <div class="header">
            Provider: <b>{{ $t('general.provider.' + $route.params.category) }}</b>
        </div>
        <div class="warning" v-if="Object.keys(categoryGames).length === 0">
            {{ $t('general.sidebar.no_games') }}
        </div>
        <games :categories="categoryGames"></games>
    </div>
</template>

<script>
    import { mapGetters } from 'vuex';

    export default {
        data() {
            return {
                categoryGames: {}
            }
        },
        computed: {
            ...mapGetters(['games', 'recentGameHistory', 'isGuest'])
        },
        created() {
            if(this.$i18n.t('general.provider.' + this.$route.params.category) === 'general.provider.' + this.$route.params.category) {
                this.$router.push('/404');
                return;
            }

            let games = this.games;
            let validateUrlCategory = true;

            let duplicates = [];
            _.forEach(games, (game) => {
                if (!validateUrlCategory || game.p.includes(this.$route.params.category)) {
                    _.forEach(game.p, (p) => {
                        if (duplicates.includes(game.id)) return;
                        duplicates.push(game.id);

                        if (!this.categoryGames[p]) this.categoryGames[p] = [game];
                        else this.categoryGames[p].push(game);
                    });
                }
            });
        }
    }
</script>

<style lang="scss" scoped>
    @import "resources/sass/variables";

    .warning {
        width: 100%;
        text-align: center;
        font-size: 1.1em;
        margin-top: 15px;
        margin-bottom: 15px;
     }

    .gameCategory {
        @include themed() {
            .header {
                background: rgba(t('sidebar'), .8);
                backdrop-filter: blur(20px);
                border-bottom: 2px solid t('border');
                margin-top: -15px;
                padding: 35px 45px;
                font-size: 1.8em;
                position: sticky;
                top: 73px;
                z-index: 555;
            }
        }
    }
</style>
