<template>
    <div class="container-fluid">
        <div :class="`game-container game-${$route.params.id}`">

            <div id="slotcontainer">
                <div class="gameWrapper">
                     <iframe data-v-7441c1cd="" :src="externalgame.url"  frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="allowfullscreen"></iframe>
                </div>
            </div>

        <div class="game-footer">externalgame.id</div>
    </div>
    </div>
</template>

<script>
    import { mapGetters } from 'vuex';

    export default {
        data() {
            return {
                externalgame: null
            }
        },
        computed: {
            ...mapGetters(['gamesExternal', 'gameInstance'])
        },
        created() {
            axios.post('/api/externalGame/getUrl', { id: this.$route.params.id }).then(({ data }) => {
                this.externalgame = data;
           });
        },
    }
</script>

<style lang="scss">
        @import "resources/sass/variables";

.game-type-third-party {
    display: flex;
    flex-direction: column;
    position: relative;
    min-height: 550px
}


.game-type-third-party iframe {
     position: absolute;
     top: 0;
     border-top-left-radius: 8px;
     border-top-right-radius: 8px;
     left: 0;
     width: 100%;
     height: 100%;
}

#slotcontainer {
    outline: none !important;
    border-bottom-right-radius: 0px;
    border-bottom-left-radius: 0px;
    margin-top: 25px;
    max-width: 1500px;
    border-top-left-radius: 16px;
    border-top-right-radius: 16px;
    padding-left: 0px !important;
    padding-right: 0px !important;
    background: #00000091;
}
.gameWrapper {
    position: relative;
    padding-bottom: 56.25%;
    height: 0;
    border-top-left-radius: 16px;
    border-top-right-radius: 16px;
}

.gameWrapper iframe {
    position: absolute;
    top: 0;
    border-top-left-radius: 16px;
    border-top-right-radius: 16px;
    left: 0;
    width: 100%;
    height: 100%;
}


 @include media-breakpoint-down(sm) {
     .gameWrapper {
         position: relative;
         padding-bottom: 1px !important;
         height: 100%;
         border-top-left-radius: 16px;
         border-top-right-radius: 16px;
         border: none !important;
    }
     .gameWrapper iframe {
         position: relative;
         top: 0;
         border-top-left-radius: 16px;
         border-top-right-radius: 16px;
         left: 0;
         width: 100%;
         height: 100%;
         min-height: 80vh;
    }
     #slotcontainer {
         background: #00000091;
         padding-right: 0px;
         margin-top: 25px;
         max-width: 1500px;
         border-top-left-radius: 0px;
         border-top-right-radius: 0px;
         padding-left: 0px !important;
         padding-right: 0px !important;
    }
}


</style>
